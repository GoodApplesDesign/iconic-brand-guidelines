Aileron by Sora Sagano (dot colon). Released with no rights reserved (CC0): free for personal and commercial use.
